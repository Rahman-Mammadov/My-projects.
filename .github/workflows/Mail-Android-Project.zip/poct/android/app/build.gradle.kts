plugins { id("com.android.application") }

android {
    namespace = "com.personalmail.app"
    compileSdk = 36                       // Android 16
    ndkVersion = "28.0.12433566"          // NDK r28: 16 KB page-size aligned libraries by default

    defaultConfig {
        applicationId = "com.personalmail.app"
        minSdk = 31                       // Android 12
        targetSdk = 36                    // Android 16
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }     // virtually every phone since 2017; add "x86_64" for the emulator
        externalNativeBuild { cmake { arguments += listOf("-DANDROID_STL=c++_static", "-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON") } }
    }
    externalNativeBuild { cmake { path = file("../../CMakeLists.txt"); version = "3.22.1" } }

    // Signing: (1) a key from the SIGNING_* environment variables (CI secrets), (2) a mail-release.jks next to this file (private builds only),
    // (3) otherwise the automatic debug key. Updates install over an older version only when the same key is used every time.
    signingConfigs {
        val envStore = System.getenv("SIGNING_KEYSTORE")
        val local = file("mail-release.jks")
        if (envStore != null || local.exists()) {
            create("mail") {
                storeFile = if (envStore != null) file(envStore) else local
                storePassword = System.getenv("SIGNING_STORE_PASSWORD") ?: "mailapp"
                keyAlias = System.getenv("SIGNING_KEY_ALIAS") ?: "mail"
                keyPassword = System.getenv("SIGNING_KEY_PASSWORD") ?: "mailapp"
            }
        }
    }
    buildTypes { release { isMinifyEnabled = false; signingConfig = signingConfigs.findByName("mail") ?: signingConfigs.getByName("debug") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
