package com.personalmail.app;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;

/** Starts the C++ mail/chat engine once per process. Used by the activity and by the background service. */
final class Engine {
    static { System.loadLibrary("poct"); }
    static final int PORT = 7878;
    /** Random per process. Only this app's WebView, service and download bridge know it, so no other app can use the local API. */
    static final String TOKEN = newToken();
    private static boolean started;

    private static native void start(String dir, int port, String token);

    private static String newToken() {
        byte[] b = new byte[24];
        new SecureRandom().nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    /** Copies the UI and CA bundle into the private files folder, starts the engine if needed and waits until it accepts connections. */
    static synchronized void ensureRunning(Context ctx) throws Exception {
        if (!started) {
            File dir = ctx.getFilesDir();
            copyAsset(ctx, "ui/index.html", new File(dir, "ui/index.html"));   // refreshed on every process start so app updates ship the new UI
            copyAsset(ctx, "cacert.pem", new File(dir, "cacert.pem"));
            start(dir.getAbsolutePath(), PORT, TOKEN);
            started = true;
        }
        for (int i = 0; i < 100; i++) {                                         // wait (max 10 s)
            try (Socket sk = new Socket()) { sk.connect(new InetSocketAddress("127.0.0.1", PORT), 200); return; }
            catch (Exception e) { Thread.sleep(100); }
        }
    }

    private static void copyAsset(Context ctx, String name, File out) throws Exception {
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        try (InputStream in = ctx.getAssets().open(name); OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
