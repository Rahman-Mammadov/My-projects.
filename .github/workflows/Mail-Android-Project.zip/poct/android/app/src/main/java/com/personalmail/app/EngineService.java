package com.personalmail.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Keeps the engine alive in the background (a foreground service, which Android requires for any app that must keep working
 * when it is not on screen) and turns the engine's "new_mail" / "chat" events into notifications.
 */
public class EngineService extends Service {
    private static final String CH_SERVICE = "service", CH_MAIL = "mail", CH_CHAT = "chat";
    private volatile boolean running;
    private Thread listener;
    private int nextId = 100;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createChannels();
        Notification n = new Notification.Builder(this, CH_SERVICE)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("Mail is running")
                .setContentText("Checking for new mail and chat messages")
                .setContentIntent(openApp())
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        if (listener == null) {
            running = true;
            listener = new Thread(this::loop, "notifier");
            listener.start();
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() { running = false; super.onDestroy(); }

    private void createChannels() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH_SERVICE, "Background service", NotificationManager.IMPORTANCE_MIN));
        nm.createNotificationChannel(new NotificationChannel(CH_MAIL, "New mail", NotificationManager.IMPORTANCE_DEFAULT));
        nm.createNotificationChannel(new NotificationChannel(CH_CHAT, "Chat messages", NotificationManager.IMPORTANCE_HIGH));
    }

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Reads the engine's event stream (Server-Sent Events) and reconnects whenever it drops. */
    private void loop() {
        while (running) {
            try {
                Engine.ensureRunning(this);
                HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:" + Engine.PORT + "/api/events").openConnection();
                c.setConnectTimeout(3000);
                c.setRequestProperty("X-Poct-Token", Engine.TOKEN);
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while (running && (line = r.readLine()) != null) {
                        if (line.startsWith("data: ")) handle(line.substring(6));
                    }
                }
            } catch (Exception ignored) { /* engine not ready or connection lost: retry below */ }
            try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
        }
    }

    private void handle(String json) {
        try {
            if (MainActivity.visible) return;                    // the app is on screen: it shows its own in-app message
            JSONObject o = new JSONObject(json);
            String type = o.optString("type");
            if ("new_mail".equals(type)) {
                String subject = o.optString("subject");
                show(CH_MAIL, displayName(o.optString("from")), subject.isEmpty() ? "(no subject)" : subject);
            } else if ("chat".equals(type)) {
                String peer = o.optString("peer");
                int at = peer.indexOf('@');
                show(CH_CHAT, at > 0 ? peer.substring(0, at) : peer, o.optString("text"));
            }
        } catch (Exception ignored) { }
    }

    private static String displayName(String from) {
        int lt = from.indexOf('<');
        if (lt > 0) {
            String name = from.substring(0, lt).replace("\"", "").trim();
            if (!name.isEmpty()) return name;
        }
        return lt >= 0 && from.indexOf('>') > lt ? from.substring(lt + 1, from.indexOf('>')) : from;
    }

    private void show(String channel, String title, String text) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        Notification n = new Notification.Builder(this, channel)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(openApp())
                .setAutoCancel(true)
                .setCategory(CH_CHAT.equals(channel) ? Notification.CATEGORY_MESSAGE : Notification.CATEGORY_EMAIL)
                .build();
        getSystemService(NotificationManager.class).notify(nextId++ % 1000 + 100, n);
    }
}
