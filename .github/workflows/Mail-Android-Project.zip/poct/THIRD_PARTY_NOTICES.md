# Third-party software

This project builds on the following open-source components. See each project's repository for its exact license text.

| Component | Used for | License |
|---|---|---|
| cpp-httplib (yhirose) | local web server | MIT |
| nlohmann/json | JSON | MIT |
| SQLite | local database and full-text search (the amalgamation is taken from the `better-sqlite3` npm package, MIT, which bundles SQLite) | Public domain |
| libsodium | end-to-end encryption and signatures | ISC |
| libsodium-cmake (robinlinden) | CMake build of libsodium for Android | see upstream |
| libcurl | IMAP, SMTP and HTTPS client | curl license (MIT-style) |
| Mbed TLS | TLS for libcurl in the Android build | Apache-2.0 (dual-licensed with GPL-2.0-or-later; used under Apache-2.0) |
| Mozilla CA certificate bundle (via the `certifi` package) | TLS trust store shipped in the Android app (`android/app/src/main/assets/cacert.pem`) | MPL-2.0 |
| Android NDK / libc++ | Android native build | Apache-2.0 with LLVM exception |

Test tooling (not shipped): Python, Playwright, QEMU.
