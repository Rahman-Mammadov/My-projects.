# Security

## What is protected
- **Local API access control.** The engine listens only on 127.0.0.1, and every request must carry a secret key (header or `SameSite=Strict` cookie) plus a loopback `Host` header. Other apps on the phone, other programs on the PC, web pages in a browser (CSRF, DNS rebinding) and CORS preflights are refused. On Android the key is random per app start and known only to the app's WebView, its background service and its download bridge. On desktop the engine prints an address containing a stored random key; open that address once and bookmark it.
- **Mail display.** HTML mail is sanitised (scripts, forms, event handlers, `javascript:` links removed) and shown in a script-less sandboxed frame with a strict Content-Security-Policy. Remote images (trackers) are blocked until you press "Show images". Attachments are served with `Content-Disposition: attachment`, `nosniff` and a sandbox CSP and are never rendered inline except a short list of safe image types.
- **Chat.** Messages are encrypted on the sender's device with libsodium (X25519 + XSalsa20-Poly1305 boxes, Ed25519 signatures) and opened only on the recipient's device. The relay stores ciphertext only. Sender keys are pinned on first contact (trust on first use) and a changed key blocks messages; compare the safety numbers shown in the chat header to rule out interception.
- **Transport.** IMAP/SMTP/HTTPS use TLS with certificate verification against the system store (desktop) or a bundled Mozilla CA list (Android).
- **Input handling.** Recipient lists and subjects are checked against header injection; uploads, messages and mailboxes have size limits; the relay rate-limits registrations and sends.

## What is NOT protected / known limits
- **Data at rest is not encrypted by the app.** Mail, mail passwords (use app passwords), chat history and private chat keys are stored in a SQLite file readable by its owner only (Android: the app's private storage). Anyone with access to your unlocked device or an unencrypted backup of this file can read them. Use full-disk encryption and a screen lock.
- **No forward secrecy and no group chats** yet (long-term keys, trust on first use).
- **The relay sees metadata** (who talks to whom, when, message sizes, IP addresses) and can drop or delay messages. Free hosts may also lose queued messages when they restart.
- Android builds made without your own signing key use a temporary debug key; do not treat such APKs as release-grade.
- This project has **not been independently audited**. Treat it as a careful personal tool, not as a hardened product.

## Reporting a vulnerability
Please open a private security advisory on the repository (Security tab) instead of a public issue.
