"""Account re-add, loading older mail, Bcc, Forward, Settings / account removal (API + browser).
Usage (from the folder containing ui/): POCT_BIN=./build/poct_core python3 tools/features_test.py"""
import email, email.policy, json, os, sqlite3, subprocess, sys, tempfile, time, urllib.request, urllib.error
HERE = os.path.dirname(os.path.abspath(__file__)); BIN = os.environ.get("POCT_BIN", "./build/poct_core"); T = tempfile.mkdtemp(); DYN = f"{T}/dyn"; os.makedirs(DYN); procs = {}
ENG, IMAP, SMTP = 7981, 14143, 14025; U = f"http://127.0.0.1:{ENG}"; os.environ["POCT_TOKEN"] = "testtoken"
def spawn(name, cmd, env=None): procs[name] = subprocess.Popen(cmd, env=dict(os.environ, **(env or {})), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
def call(path, body=None, method=None):
    r = urllib.request.Request(U + path, data=json.dumps(body).encode() if body is not None else None, method=method, headers={"Content-Type": "application/json", "X-Poct-Token": "testtoken"})
    try:
        with urllib.request.urlopen(r, timeout=120) as x: return x.status, json.loads(x.read() or b"null")
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read() or b"null")
        except Exception: return e.code, None
def wait(fn, t=25):
    end = time.time() + t
    while time.time() < end:
        try:
            v = fn()
            if v: return v
        except Exception: pass
        time.sleep(0.3)
n = 0
def ok(name, cond):
    global n; n += 1; print(("PASS  " if cond else "FAIL  ") + name)
    if not cond: raise AssertionError(name)
def db(sql, args=()):
    con = sqlite3.connect(f"{T}/e.db", timeout=10); r = con.execute(sql, args).fetchall(); con.close(); return r
def last_mail():
    blk = [b for b in open(f"{T}/smtp_got.txt", "rb").read().split(b"=====\n") if b.strip()][-1]
    return email.message_from_bytes(blk.rsplit(b"\r\n.\r\n", 1)[0], policy=email.policy.default)
ACC = lambda e, pw="good": {"email": e, "password": pw, "imap_host": "127.0.0.1", "imap_port": IMAP, "smtp_host": "127.0.0.1", "smtp_port": SMTP, "tls": False}
try:
    for i in range(1001, 1061): open(f"{DYN}/{i}.eml", "w", encoding="utf-8").write(f"From: Sender {i} <s{i}@shop.example>\r\nSubject: Message number {i}\r\nDate: Sat, 03 Oct 2026 12:00:00 +0000\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nBody of {i}.\r\n")
    spawn("mock", [sys.executable, f"{HERE}/mock_mail_server.py"], {"MOCK_DYNAMIC": DYN, "MOCK_IMAP_PORT": str(IMAP), "MOCK_SMTP_PORT": str(SMTP), "MOCK_OUT": T}); spawn("eng", [BIN, "--db", f"{T}/e.db"], {"POCT_PORT": str(ENG)})
    ok("engine starts", bool(wait(lambda: call("/api/accounts")[0] == 200, 10))); time.sleep(1)
    s, r = call("/api/accounts", ACC("a@mock.az")); acc1 = r["id"]; ok("account added", s == 200)
    cnt = lambda acct=None: len(call("/api/messages?folder=inbox" + (f"&account={acct}" if acct else ""))[1])
    ok("first sync takes the newest 50 of 63 messages", bool(wait(lambda: cnt(acc1) == 50)))
    # --- re-adding an account (new password) must not orphan its mail
    s, r = call("/api/accounts", ACC("a@mock.az", "good2")); ok("re-adding the same address keeps its id", s == 200 and r["id"] == acc1)
    time.sleep(2); ok("mail stays attached, nothing duplicated or re-downloaded", cnt(acc1) == 50 and len(call("/api/accounts")[1]) == 1)
    ok("password was updated", db("select pass from accounts where id=?", (acc1,))[0][0] == "good2")
    s, r = call("/api/accounts", ACC("a@mock.az", "bad")); ok("wrong new password is rejected and the old one is kept", s == 400 and db("select pass from accounts where id=?", (acc1,))[0][0] == "good2")
    # --- older mail
    s, r = call("/api/older", {"account": acc1}); ok("'load older' fetches the remaining 13 messages", s == 200 and r["added"] == 13 and r["more"] is False and cnt(acc1) == 63)
    s, r = call("/api/older", {"account": acc1}); ok("second 'load older' finds nothing and does not duplicate", r["added"] == 0 and cnt(acc1) == 63)
    ok("unknown account -> 400", call("/api/older", {"account": 999})[0] == 400)
    # --- Bcc
    s, r = call("/api/send", {"account": acc1, "to": "to@x.az", "bcc": "hidden@x.az", "subject": "Bcc test", "body": "hi"}); mm = last_mail(); cmds = open(f"{T}/smtp_cmds.txt").read().lower()
    ok("Bcc recipient receives the mail but is not in any header", s == 200 and "<hidden@x.az>" in cmds and "<to@x.az>" in cmds and mm["Bcc"] is None and "hidden@x.az" not in str(mm["To"]) )
    ok("invalid Bcc is rejected", call("/api/send", {"account": acc1, "to": "to@x.az", "bcc": "not-an-address", "subject": "x", "body": "y"})[0] == 400)
    # --- browser
    s, r = call("/api/accounts", ACC("two@mock.az")); acc2 = r["id"]; ok("second account added", bool(wait(lambda: cnt(acc2) == 50)))
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); ctx = b.new_context(viewport={"width": 1280, "height": 800}); pg = ctx.new_page(); errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(U + "/?t=testtoken"); pg.wait_for_selector(".row"); ok("UI: 'Load older messages' button at the end of the inbox", pg.locator("#older").count() == 1)
        before = pg.locator(".row").count(); pg.click("#older"); pg.wait_for_function("document.querySelector('#toast').textContent.includes('older message')"); pg.wait_for_function(f"document.querySelectorAll('.row').length>{before}")
        ok("UI: older messages loaded and listed (113 -> 126) with a clear message", before == 113 and pg.locator(".row").count() == 126 and "(that is all)" in pg.inner_text("#toast"))
        pg.click(".row >> nth=0"); pg.wait_for_selector("#fwd"); pg.click("#fwd"); pg.wait_for_selector("#win.open")
        ok("UI: Forward opens a composer with 'Fwd:' subject, empty To and the original quoted", pg.input_value("#sub").startswith("Fwd: Message number") and pg.input_value("#to") == "" and "Forwarded message" in pg.inner_text("#rt") and "Body of" in pg.inner_text("#rt"))
        pg.fill("#to", "friend@x.az"); pg.fill("#bcc", "secret@x.az"); pg.click("#send"); pg.wait_for_function("document.querySelector('#toast').textContent==='Sent'")
        mm = last_mail(); cmds = open(f"{T}/smtp_cmds.txt").read().lower(); ok("UI: forward sent; Bcc used for delivery only", mm["Subject"].startswith("Fwd:") and "<secret@x.az>" in cmds and mm["Bcc"] is None)
        pg.click("#setb"); pg.wait_for_selector("#am.open"); ok("UI: Settings lists both accounts", "a@mock.az" in pg.inner_text("#alist") and "two@mock.az" in pg.inner_text("#alist")); pg.screenshot(path="/tmp/t/features_settings.png")
        pg.click('[data-rm="%d"]' % acc2); ok("UI: removal asks for confirmation first", pg.locator("[data-yes]").count() == 1 and len(call("/api/accounts")[1]) == 2)
        pg.click("[data-no]"); ok("UI: Cancel keeps the account", pg.locator("[data-yes]").count() == 0 and len(call("/api/accounts")[1]) == 2)
        pg.click('[data-rm="%d"]' % acc2); pg.click("[data-yes]"); pg.wait_for_function("document.querySelector('#toast').textContent==='Account removed'")
        ok("UI: account removed together with its mail and attachments", [a["email"] for a in call("/api/accounts")[1]] == ["a@mock.az"] and db("select count(*) from mails where account_id=?", (acc2,))[0][0] == 0)
        pg.click("#ax2"); pg.wait_for_function("document.querySelectorAll('.row').length===63"); ok("UI: inbox now shows only the remaining account's 63 messages", True)
        pm = ctx.new_page(); pm.set_viewport_size({"width": 390, "height": 780}); pm.goto(U + "/"); pm.wait_for_selector(".row"); pm.click("#menu"); pm.wait_for_timeout(300); pm.click("#setb"); pm.wait_for_selector("#am.open")
        ok("UI mobile: Settings reachable from the drawer", "a@mock.az" in pm.inner_text("#alist")); ok("no JS exceptions", errs == []); b.close()
    print(f"\nALL {n} FEATURE TESTS PASSED")
finally:
    for pr in procs.values(): pr.terminate()
