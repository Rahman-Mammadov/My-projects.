"""End-to-end test of HTML mail safety, attachments, rich composer, drafts and the chat-server probe.
Usage (from the folder containing ui/):  POCT_BIN=./build/poct_core python3 tools/rich_test.py   (needs: pip install playwright && playwright install chromium)"""
import base64, email, email.policy, json, os, sqlite3, subprocess, sys, tempfile, time, urllib.parse, urllib.request, urllib.error
HERE = os.path.dirname(os.path.abspath(__file__)); BIN = os.environ.get("POCT_BIN", "./build/poct_core"); T = tempfile.mkdtemp(); procs = {}
ENG, IMAP, SMTP, R1, R2 = 7960, 12143, 12025, 9101, 9102; U = f"http://127.0.0.1:{ENG}"
def spawn(name, cmd, env=None): procs[name] = subprocess.Popen(cmd, env=dict(os.environ, **(env or {})), stdout=subprocess.DEVNULL, stderr=open(f"{T}/err_{name}.log", "w"))
def call(path, body=None, port=ENG):
    r = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=json.dumps(body).encode() if body is not None else None, headers={"Content-Type": "application/json", "X-Poct-Token": "testtoken"})
    try:
        with urllib.request.urlopen(r, timeout=120) as x: return x.status, json.loads(x.read() or b"null")
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read() or b"null")
        except Exception: return e.code, None
def raw(path):
    try:
        with urllib.request.urlopen(urllib.request.Request(f"{U}{path}", headers={"X-Poct-Token": "testtoken"}), timeout=30) as x: return x.status, dict(x.headers), x.read()
    except urllib.error.HTTPError as e: return e.code, dict(e.headers), e.read()
def wait(fn, t=15):
    end = time.time() + t
    while time.time() < end:
        try:
            v = fn()
            if v: return v
        except Exception: pass
        time.sleep(0.3)
os.environ["POCT_TOKEN"] = "testtoken"
n = 0
def ok(name, cond):
    global n; n += 1; print(("PASS  " if cond else "FAIL  ") + name)
    if not cond: raise AssertionError(name)
def last_mail():
    data = open(f"{T}/smtp_got.txt", "rb").read().split(b"=====\n"); blk = [b for b in data if b.strip()][-1]
    return email.message_from_bytes(blk.rsplit(b"\r\n.\r\n", 1)[0], policy=email.policy.default)
def b64(b): return base64.b64encode(b).decode()
try:
    spawn("mock", [sys.executable, f"{HERE}/mock_mail_server.py"], {"MOCK_RICH": "1", "MOCK_IMAP_PORT": str(IMAP), "MOCK_SMTP_PORT": str(SMTP), "MOCK_OUT": T})
    spawn("eng", [BIN, "--db", f"{T}/e.db"], {"POCT_PORT": str(ENG)})
    spawn("r1", [BIN, "--relay", "--port", str(R1), "--db", f"{T}/r1.db"], {"POCT_INVITE": "secret"}); spawn("r2", [BIN, "--relay", "--port", str(R2), "--db", f"{T}/r2.db"])
    ok("everything starts", all(wait(lambda p=p: call("/api/accounts" if p == ENG else "/relay/health", port=p)[0] == 200, 10) for p in (ENG, R1, R2)))
    time.sleep(1)
    s, r = call("/api/accounts", {"email": "rich@mock.az", "password": "good", "imap_host": "127.0.0.1", "imap_port": IMAP, "smtp_host": "127.0.0.1", "smtp_port": SMTP, "tls": False}); ok("account added", s == 200)
    rows = wait(lambda: (lambda x: x if len(x) == 2 else None)(call("/api/messages?folder=inbox")[1])); ok("2 messages synced", bool(rows))
    rich = [m for m in rows if m["subject"] == "Weekly newsletter"][0]; plain = [m for m in rows if m["subject"] == "Plain message"][0]
    ok("list reports 4 attachments on the newsletter, 0 on plain", rich["att"] == 4 and plain["att"] == 0)
    s, m = call(f"/api/message/{rich['id']}"); atts = {a["name"]: a for a in m["attachments"]}
    ok("html part kept, plain part kept", "<script" in m["html"] and "Plain version: Hello team" in m["body"])
    ok("attachment names incl. RFC2231 unicode filename", {"report.txt", "Hesabat-Əlavə.txt", "evil.html"} <= set(atts) and any(a["cid"] == "logo123" for a in m["attachments"]))
    # --- attachment download endpoint
    st, h, d = raw(f"/api/attachment/{atts['report.txt']['id']}"); ok("download bytes identical + safe headers", d == b"Quarterly report\nline two" and h["Content-Disposition"].startswith("attachment") and h["X-Content-Type-Options"] == "nosniff" and "sandbox" in h["Content-Security-Policy"])
    st, h, d = raw(f"/api/attachment/{atts['Hesabat-Əlavə.txt']['id']}"); ok("unicode attachment bytes + filename*", d == "Əlavə fayl məzmunu".encode() and urllib.parse.unquote(h["Content-Disposition"].split("filename*=UTF-8''")[1]) == "Hesabat-Əlavə.txt")
    logo = [a for a in m["attachments"] if a["cid"] == "logo123"][0]
    st, h, d = raw(f"/api/attachment/{logo['id']}?inline=1"); ok("inline image allowed for png", h["Content-Disposition"].startswith("inline") and h["Content-Type"] == "image/png" and len(d) > 20)
    st, h, d = raw(f"/api/attachment/{atts['evil.html']['id']}?inline=1"); ok("html attachment can never be shown inline (stored-XSS guard)", h["Content-Disposition"].startswith("attachment") and h["Content-Type"] == "application/octet-stream")
    ok("unknown attachment -> 404", raw("/api/attachment/99999")[0] == 404)
    ok("search finds body text", any(x["id"] == rich["id"] for x in call("/api/search?q=quarterly")[1]) and any(x["id"] == rich["id"] for x in call("/api/search?q=newsletter")[1]))
    # --- sending: html + cc + attachments + Unicode, header injection, limits
    blob = os.urandom(300000)
    pay = {"account": 1, "to": "a@b.az, C Person <c@d.az>", "cc": "e@f.az", "subject": "Report Əlavə", "body": "Hello plain", "html": "<div>Hello <b>bold</b></div>",
           "attachments": [{"name": "Hesabat-Əlavə.bin", "mime": "application/octet-stream", "data": b64(blob)}, {"name": "note.txt", "mime": "text/plain", "data": b64(b"hi\n.\nthere\n")}]}
    s, r = call("/api/send", pay); ok("send with attachments succeeds", s == 200)
    msg = last_mail(); got = {a.get_filename(): a.get_payload(decode=True) for a in msg.iter_attachments()}
    ok("received MIME: mixed/alternative, subject, To, Cc", msg.get_content_type() == "multipart/mixed" and msg["Subject"] == "Report Əlavə" and "c@d.az" in msg["To"] and msg["Cc"] == "e@f.az")
    ok("received attachments byte-identical (300 KB binary, unicode name)", got.get("Hesabat-Əlavə.bin") == blob and got.get("note.txt") == b"hi\n.\nthere\n")
    ok("received text + html bodies", msg.get_body(("plain",)).get_content().strip() == "Hello plain" and "<b>bold</b>" in msg.get_body(("html",)).get_content())
    cmds = open(f"{T}/smtp_cmds.txt").read().lower(); ok("SMTP envelope includes To and Cc recipients", all(x in cmds for x in ("<a@b.az>", "<c@d.az>", "<e@f.az>")))
    sent = [x for x in call("/api/messages?folder=sent")[1] if x["subject"] == "Report Əlavə"]; ok("sent copy stored with 2 attachments", len(sent) == 1 and sent[0]["att"] == 2)
    s, r = call("/api/send", dict(pay, subject="Hi\r\nBcc: evil@x.az", attachments=[])); mm = last_mail(); ok("CRLF injection in subject cannot add headers", s == 200 and mm["Bcc"] is None)
    ok("CRLF injection in recipient rejected", call("/api/send", dict(pay, to="a@b.az\r\nBcc: x@y.az"))[0] == 400)
    ok("invalid recipient rejected", call("/api/send", dict(pay, to="nobody"))[0] == 400)
    ok("attachments over 20 MB refused", call("/api/send", dict(pay, attachments=[{"name": "big", "mime": "x/y", "data": b64(b"\0" * 21_000_000)}]))[0] == 413)
    # --- drafts API + FTS integrity
    s, d1 = call("/api/draft", {"account": 1, "to": "x@y.az", "subject": "Draft one", "body": "first", "html": "<p>first</p>"}); s, d2 = call("/api/draft", {"id": d1["id"], "account": 1, "to": "x@y.az", "subject": "Draft one v2", "body": "second", "html": "<p>second</p>"})
    ok("draft update keeps the same id", d1["id"] == d2["id"] and len(call("/api/messages?folder=drafts")[1]) == 1)
    s, dm = call(f"/api/message/{d1['id']}"); ok("draft returns recipients/html", dm["to_addr"] == "x@y.az" and dm["subject"] == "Draft one v2" and dm["html"] == "<p>second</p>")
    ok("updated draft is searchable by new text only", any(x["id"] == d1["id"] for x in call("/api/search?q=second")[1]) and not any(x["id"] == d1["id"] for x in call("/api/search?q=first")[1]))
    call("/api/mark", {"id": d1["id"], "folder": "purge"}); con = sqlite3.connect(f"{T}/e.db", timeout=10)
    con.execute("INSERT INTO mails_fts(mails_fts) VALUES('integrity-check')"); ok("FTS index and database integrity intact", con.execute("PRAGMA integrity_check").fetchone()[0] == "ok"); con.rollback(); con.close()   # never keep a write lock open on the engine's database
    # --- chat server probe
    s, r = call(f"/api/chat/probe?url=127.0.0.1:{R1}"); ok("probe: relay with invite", s == 200 and r["invite_required"] is True)
    s, r = call(f"/api/chat/probe?url=http://127.0.0.1:{R2}/"); ok("probe: open relay", s == 200 and r["invite_required"] is False)
    s, r = call(f"/api/chat/probe?url=127.0.0.1:{ENG}"); ok("probe: not a relay -> clear error", s == 400 and "not a Mail chat server" in r["error"])
    ok("probe: unreachable -> 502", call("/api/chat/probe?url=127.0.0.1:9")[0] == 502); ok("probe: plain http to public host refused", call("/api/chat/probe?url=http://example.com")[0] == 400)
    # --- browser
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); ctx = b.new_context(viewport={"width": 1280, "height": 800}, accept_downloads=True); pg = ctx.new_page(); dialogs = []; errs = []
        pg.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss())); pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.add_init_script("window.__opened=[];window.open=(u)=>{window.__opened.push(u);return null}")
        pg.goto(U + "/?t=testtoken"); pg.wait_for_function("document.querySelectorAll('.row').length===2"); ok("UI: paperclip shown only on the mail with attachments", pg.locator(".row svg.clip").count() == 1)
        pg.click(".row >> text=Weekly newsletter"); pg.wait_for_selector("iframe.mailframe"); fr = pg.query_selector("iframe.mailframe").content_frame(); fr.wait_for_selector("h1"); pg.wait_for_timeout(500)
        info = fr.evaluate("""()=>({sc:document.querySelectorAll('script,iframe,form,svg,input').length,
          on:[...document.querySelectorAll('*')].some(e=>[...e.attributes].some(a=>a.name.startsWith('on'))),
          js:[...document.querySelectorAll('a')].some(a=>/^javascript/i.test(a.getAttribute('href')||'')),
          track:document.querySelector('#track')&&document.querySelector('#track').hasAttribute('src'),
          logo:document.querySelector('#logo').getAttribute('src'),logoW:document.querySelector('#logo').naturalWidth,
          bad:document.querySelector('#bad')&&document.querySelector('#bad').hasAttribute('src'),
          csp:document.querySelector('meta[http-equiv="Content-Security-Policy"]').content,head:document.head.innerHTML})""")
        ok("UI: scripts, iframes, forms, svg, inputs all stripped", info["sc"] == 0); ok("UI: no event-handler attributes, no javascript: links", not info["on"] and not info["js"])
        ok("UI: tracking pixel blocked, broken src dropped", not info["track"] and not info["bad"]); ok("UI: @import removed from styles", "@import" not in info["head"])
        ok("UI: CSP blocks remote content by default", "default-src 'none'" in info["csp"] and "https:" not in info["csp"])
        ok("UI: inline cid image resolved and actually loads", info["logo"] == f"/api/attachment/{logo['id']}?inline=1" and info["logoW"] == 1)
        ok("UI: privacy banner shown", "Images are hidden" in pg.inner_text(".note")); ok("UI: no alert() fired by any of the 6 XSS attempts", dialogs == [])
        chips = pg.locator(".chips a.chip"); ok("UI: 3 attachment chips (inline logo excluded)", chips.count() == 3)
        with pg.expect_download() as dl: pg.click("a.chip >> text=report.txt")
        ok("UI: attachment downloads with right name and bytes", dl.value.suggested_filename == "report.txt" and open(dl.value.path(), "rb").read() == b"Quarterly report\nline two")
        with pg.expect_download() as dl: pg.click("a.chip >> text=Hesabat")
        ok("UI: unicode attachment name preserved", dl.value.suggested_filename == "Hesabat-Əlavə.txt")
        fr.click('a[href^="https://example.org"]'); ok("UI: links open externally via the bridge path", pg.evaluate("window.__opened") == ["https://example.org/page"])
        ok("UI: javascript: link was neutralised", fr.evaluate("[...document.querySelectorAll('a')].find(a=>a.textContent==='bad link').hasAttribute('href')") is False)
        pg.screenshot(path="/tmp/t/rich_view.png")
        pg.click("#si"); pg.wait_for_function("!document.querySelector('.note')"); fr = pg.query_selector("iframe.mailframe").content_frame(); fr.wait_for_selector("h1")
        ok("UI: 'Show images' enables remote images only after the click", fr.evaluate("document.querySelector('#track').getAttribute('src')") == "https://tracker.example/pixel.gif")
        fr.click('a[href^="mailto:"]'); pg.wait_for_selector("#win.open"); ok("UI: mailto link opens composer prefilled", pg.input_value("#to") == "boss@example.org" and pg.input_value("#sub") == "Hi boss"); pg.click("#discard")
        pg.click("#back"); pg.click(".row >> text=Plain message"); pg.wait_for_selector(".msg pre"); ok("UI: plain mail shows text, no iframe", pg.locator("iframe.mailframe").count() == 0 and "Just text." in pg.inner_text(".msg pre")); pg.click("#back")
        # composer
        pg.click("#nc"); pg.wait_for_selector("#win.open"); pg.fill("#to", "dest@example.org"); pg.fill("#cc", "cc@example.org"); pg.fill("#sub", "Rich Subject Əə")
        pg.click("#rt"); pg.keyboard.type("Hello "); pg.click("[data-cmd=bold]"); pg.keyboard.type("bold"); pg.click("[data-cmd=bold]"); pg.keyboard.type(" and link")
        pg.keyboard.press("Shift+Control+ArrowLeft"); pg.click("[data-cmd=createLink]"); pg.fill("#lku", "https://example.org/x"); pg.press("#lku", "Enter")
        ok("UI: bold and link applied in editor", "<b>bold</b>" in pg.inner_html("#rt") and 'href="https://example.org/x"' in pg.inner_html("#rt"))
        pg.keyboard.press("Control+End")
        pg.evaluate("""()=>{const dt=new DataTransfer();dt.setData('text/plain','pasted <i>text</i>');dt.setData('text/html','<b>x</b>');document.querySelector('#rt').dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}))}""")
        ok("UI: paste is inserted as plain text only", "pasted &lt;i&gt;text&lt;/i&gt;" in pg.inner_html("#rt"))
        pg.evaluate("""()=>{const r=document.querySelector('#rt');const a=document.createElement('a');a.setAttribute('href','javascript:alert(3)');a.textContent='J';r.appendChild(a);const s=document.createElement('span');s.setAttribute('onclick','alert(2)');s.textContent='S';r.appendChild(s)}""")
        pg.set_input_files("#files", [{"name": "Hesabat-Əlavə.bin", "mimeType": "application/octet-stream", "buffer": blob}, {"name": "note.txt", "mimeType": "text/plain", "buffer": b"hello note"}])
        ok("UI: two attachment chips", pg.locator("#chips .chip").count() == 2); pg.click('[data-rm="0"]'); ok("UI: chip can be removed", pg.locator("#chips .chip").count() == 1)
        pg.set_input_files("#files", [{"name": "Hesabat-Əlavə.bin", "mimeType": "application/octet-stream", "buffer": blob}]); pg.screenshot(path="/tmp/t/rich_compose.png"); pg.click("#send")
        pg.wait_for_function("document.querySelector('#toast').textContent==='Sent'"); mm = last_mail(); html = mm.get_body(("html",)).get_content()
        ok("UI send: structure, Cc, formatting kept", mm.get_content_type() == "multipart/mixed" and mm["Cc"] == "cc@example.org" and "<b>bold</b>" in html and 'href="https://example.org/x"' in html)
        ok("UI send: injected javascript:/onclick stripped before sending", "javascript:" not in html and "onclick" not in html)
        ok("UI send: attachments byte-identical", {a.get_filename(): a.get_payload(decode=True) for a in mm.iter_attachments()} == {"Hesabat-Əlavə.bin": blob, "note.txt": b"hello note"})
        ok("UI send: plain-text alternative present", "Hello bold" in mm.get_body(("plain",)).get_content())
        # drafts
        pg.click("#nc"); pg.wait_for_selector("#win.open"); pg.fill("#to", "later@example.org"); pg.fill("#sub", "Draft subject"); pg.click("#rt"); pg.keyboard.type("draft body"); pg.click("#wx")
        pg.wait_for_function("document.querySelector('#toast').textContent==='Draft saved'"); pg.click("[data-f=drafts]"); pg.wait_for_selector("[data-f=drafts].on"); pg.wait_for_selector(".row")
        ok("UI: closing with content saves a draft", pg.locator(".row").count() == 1 and "Draft subject" in pg.inner_text(".row"))
        pg.click(".row"); pg.wait_for_selector("#win.open"); ok("UI: opening a draft restores the composer", pg.input_value("#to") == "later@example.org" and pg.input_value("#sub") == "Draft subject" and "draft body" in pg.inner_text("#rt"))
        pg.click("#rt"); pg.keyboard.press("Control+End"); pg.keyboard.type(" more"); pg.click("#wx"); pg.wait_for_timeout(700)
        ok("UI: re-saving updates the same draft (no duplicates)", pg.locator(".row").count() == 1 and "more" in pg.inner_text(".row"))
        pg.click(".row"); pg.wait_for_selector("#win.open"); pg.click("#send"); pg.wait_for_function("document.querySelector('#toast').textContent==='Sent'"); pg.wait_for_timeout(600)
        ok("UI: sending a draft removes it from Drafts", "No messages" in pg.inner_text("#pane")); pg.click("[data-f=sent]"); pg.wait_for_selector("[data-f=sent].on"); pg.wait_for_timeout(300); ok("UI: sent draft is in Sent", "Draft subject" in pg.inner_text("#pane"))
        pg.click("#nc"); pg.wait_for_selector("#win.open"); pg.fill("#sub", "Thrown away"); pg.click("#discard"); pg.click("[data-f=drafts]"); pg.wait_for_selector("[data-f=drafts].on"); pg.wait_for_timeout(300); ok("UI: Discard saves nothing", "No messages" in pg.inner_text("#pane"))
        # chat server wizard
        pg.click("#tc"); pg.wait_for_selector("#stest"); ok("UI: wizard shows server test + guide", "I don't have a server yet" in pg.inner_text("#pane"))
        pg.fill("#su", f"127.0.0.1:{R1}"); pg.click("#stest"); pg.wait_for_function("document.querySelector('#sres').textContent!=='' && document.querySelector('#sres').textContent!=='Checking…'"); pg.wait_for_function("document.querySelector('#sres').textContent.includes('Server found')"); ok("UI: test reports invite required", "invite code" in pg.inner_text("#sres"))
        pg.fill("#su", f"127.0.0.1:{R2}"); pg.click("#stest"); pg.wait_for_function("document.querySelector('#sres').textContent.includes('No invite')"); ok("UI: test reports open server", True)
        pg.fill("#su", "127.0.0.1:9"); pg.click("#stest"); pg.wait_for_function("document.querySelector('#sres').className==='err'"); ok("UI: test reports unreachable server", "Could not reach" in pg.inner_text("#sres"))
        # mobile composer
        pm = ctx.new_page(); pm.set_viewport_size({"width": 390, "height": 780}); pm.goto(U + "/?t=testtoken"); pm.wait_for_selector(".row"); pm.screenshot(path="/tmp/t/rich_mobile_list.png"); pm.click("#fab"); pm.wait_for_selector("#win.open")
        bb = pm.locator("#send").bounding_box(); ok("UI mobile: composer fits the screen with Send reachable", bb is not None and bb["y"] + bb["height"] <= 780 and bb["x"] >= 0); pm.screenshot(path="/tmp/t/rich_mobile.png")
        ok("no JS exceptions, no dialogs at all", errs == [] and dialogs == []); b.close()
    print(f"\nALL {n} RICH-MAIL TESTS PASSED")
finally:
    for pr in procs.values(): pr.terminate()
