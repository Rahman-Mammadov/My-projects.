"""Access-control tests for the local API (other apps, other programs and web pages can all reach 127.0.0.1).
Usage (from the folder containing ui/): POCT_BIN=./build/poct_core python3 tools/security_test.py"""
import http.client, json, os, subprocess, tempfile, time
BIN = os.environ.get("POCT_BIN", "./build/poct_core"); T = tempfile.mkdtemp(); PORT, RL = 7980, 9121; TOK = "s3cret-test-token-0123456789"; procs = []
def req(method, path, headers=None, body=None, port=PORT, host=None):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=20); h = dict(headers or {})
    if host is not None: h["Host"] = host
    c.putrequest(method, path, skip_host=host is not None, skip_accept_encoding=True)
    for k, v in h.items(): c.putheader(k, v)
    data = body.encode() if isinstance(body, str) else body
    if data is not None: c.putheader("Content-Length", str(len(data)))
    c.endheaders(data); r = c.getresponse(); b = r.read(); hd = {k.lower(): v for k, v in r.getheaders()}; c.close(); return r.status, hd, b
n = 0
def ok(name, cond):
    global n; n += 1; print(("PASS  " if cond else "FAIL  ") + name)
    if not cond: raise AssertionError(name)
try:
    procs.append(subprocess.Popen([BIN, "--db", f"{T}/e.db"], env=dict(os.environ, POCT_PORT=str(PORT), POCT_TOKEN=TOK), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
    procs.append(subprocess.Popen([BIN, "--relay", "--port", str(RL), "--db", f"{T}/r.db"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
    for _ in range(40):
        try: req("GET", "/relay/health", port=RL); req("GET", "/", {"X-Poct-Token": TOK}); break
        except Exception: time.sleep(0.25)
    H = {"X-Poct-Token": TOK}
    for path in ("/", "/api/accounts", "/api/messages?folder=inbox", "/api/events", "/api/chat/identity", "/index.html"):
        ok(f"no token -> 403: {path}", req("GET", path)[0] == 403)
    ok("wrong token -> 403", req("GET", "/api/accounts", {"X-Poct-Token": TOK[:-1] + "x"})[0] == 403 and req("GET", "/api/accounts", {"X-Poct-Token": ""})[0] == 403)
    ok("token in the query string is NOT accepted on API paths", req("GET", f"/api/accounts?t={TOK}")[0] == 403)
    ok("correct header token -> 200", req("GET", "/api/accounts", H)[0] == 200)
    st, hd, _ = req("GET", f"/?t={TOK}"); ok("opening /?t=KEY sets a HttpOnly, SameSite=Strict cookie and redirects to /", st == 302 and hd["location"] == "/" and "HttpOnly" in hd["set-cookie"] and "SameSite=Strict" in hd["set-cookie"] and f"poct_t={TOK}" in hd["set-cookie"])
    ck = {"Cookie": f"poct_t={TOK}"}; ok("the cookie alone is enough for the UI and the API", req("GET", "/", ck)[0] == 200 and req("GET", "/api/accounts", ck)[0] == 200)
    ok("wrong cookie -> 403", req("GET", "/api/accounts", {"Cookie": "poct_t=nope"})[0] == 403)
    ok("DNS-rebinding / foreign Host header is refused even with the key", req("GET", "/api/accounts", H, host="evil.example")[0] == 403 and req("GET", "/api/accounts", H, host=f"evil.example:{PORT}")[0] == 403)
    ok("localhost Host header is accepted", req("GET", "/api/accounts", H, host=f"localhost:{PORT}")[0] == 200)
    # CSRF / cross-origin
    st, hd, _ = req("POST", "/api/send", {"Origin": "https://evil.example", "Content-Type": "text/plain"}, '{"account":1,"to":"a@b.az","subject":"x","body":"y"}'); ok("cross-site 'simple' POST (text/plain) cannot send mail", st == 403)
    st, hd, _ = req("OPTIONS", "/api/send", {"Origin": "https://evil.example", "Access-Control-Request-Method": "POST"}); ok("CORS preflight is refused and grants nothing", st == 403 and "access-control-allow-origin" not in hd)
    st, hd, _ = req("GET", "/api/accounts", dict(H, Origin="https://evil.example")); ok("no Access-Control-Allow-Origin header is ever sent (browsers cannot read responses cross-site)", st == 200 and "access-control-allow-origin" not in hd)
    for path in ("/api/send", "/api/accounts", "/api/draft", "/api/mark", "/api/chat/setup"): ok(f"unauthenticated POST refused: {path}", req("POST", path, {"Content-Type": "application/json"}, "{}")[0] == 403)
    ok("unauthenticated DELETE refused", req("DELETE", "/api/accounts/1")[0] == 403)
    ok("attachments need the key too", req("GET", "/api/attachment/1")[0] == 403)
    # relay mode is public by design (it only handles ciphertext) and must be unaffected
    ok("relay endpoints work without any key (separate mode)", req("GET", "/relay/health", port=RL)[0] == 200)
    # token survives restart (stored) when not given via env
    procs[0].terminate(); procs[0].wait(); procs[0] = subprocess.Popen([BIN, "--db", f"{T}/e.db"], env={k: v for k, v in os.environ.items() if k != "POCT_TOKEN"} | {"POCT_PORT": str(PORT)}, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    line = procs[0].stdout.readline().decode(); key = line.rsplit("?t=", 1)[1].strip(); ok("without POCT_TOKEN the engine creates a random key and prints the open-this address", len(key) == 48 and key != TOK)
    time.sleep(0.5); ok("generated key works and the old one no longer does", req("GET", "/api/accounts", {"X-Poct-Token": key})[0] == 200 and req("GET", "/api/accounts", H)[0] == 403)
    procs[0].terminate(); procs[0].wait(); procs[0] = subprocess.Popen([BIN, "--db", f"{T}/e.db"], env={k: v for k, v in os.environ.items() if k != "POCT_TOKEN"} | {"POCT_PORT": str(PORT)}, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    key2 = procs[0].stdout.readline().decode().rsplit("?t=", 1)[1].strip(); ok("the generated key is stable across restarts (bookmarkable address)", key2 == key)
    print(f"\nALL {n} SECURITY TESTS PASSED")
finally:
    for p in procs: p.terminate()
