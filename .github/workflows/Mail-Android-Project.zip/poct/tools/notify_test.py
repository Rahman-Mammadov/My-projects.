"""Checks the events the Android app turns into notifications: new_mail (never for the first sync, capped at 5 per sync), chat previews, and configurable polling.
Usage (from the folder containing ui/): POCT_BIN=./build/poct_core python3 tools/notify_test.py"""
import json, os, subprocess, sys, tempfile, threading, time, urllib.request, urllib.error
HERE = os.path.dirname(os.path.abspath(__file__)); BIN = os.environ.get("POCT_BIN", "./build/poct_core"); T = tempfile.mkdtemp(); DYN = f"{T}/dyn"; os.makedirs(DYN); procs = {}
E1, E2, AL, BO, RL, IMAP, SMTP = 7970, 7973, 7971, 7972, 9111, 13143, 13025
def spawn(name, cmd, env=None): procs[name] = subprocess.Popen(cmd, env=dict(os.environ, **(env or {})), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
def call(port, path, body=None):
    r = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=json.dumps(body).encode() if body is not None else None, headers={"Content-Type": "application/json", "X-Poct-Token": "testtoken"})
    try:
        with urllib.request.urlopen(r, timeout=60) as x: return x.status, json.loads(x.read() or b"null")
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read() or b"null")
        except Exception: return e.code, None
class Sse:
    def __init__(self, port):
        self.events = []; self.stop = False; threading.Thread(target=self.run, args=(port,), daemon=True).start(); time.sleep(0.6)
    def run(self, port):
        try:
            with urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{port}/api/events", headers={"X-Poct-Token": "testtoken"}), timeout=300) as x:
                for line in x:
                    if self.stop: return
                    if line.startswith(b"data: "): self.events.append(json.loads(line[6:]))
        except Exception: pass
    def of(self, t): return [e for e in self.events if e.get("type") == t]
def wait(fn, t=20):
    end = time.time() + t
    while time.time() < end:
        try:
            v = fn()
            if v: return v
        except Exception: pass
        time.sleep(0.3)
os.environ["POCT_TOKEN"] = "testtoken"
n = 0
def ok(name, cond):
    global n; n += 1; print(("PASS  " if cond else "FAIL  ") + name)
    if not cond: raise AssertionError(name)
def eml(num, subject):
    open(f"{DYN}/{num}.eml", "w", encoding="utf-8").write(f"From: Billing <billing@shop.example>\r\nSubject: {subject}\r\nDate: Sat, 03 Oct 2026 12:00:00 +0000\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nYour invoice is ready.\r\n")
ACC = {"email": "n@mock.az", "password": "good", "imap_host": "127.0.0.1", "imap_port": IMAP, "smtp_host": "127.0.0.1", "smtp_port": SMTP, "tls": False}
try:
    spawn("mock", [sys.executable, f"{HERE}/mock_mail_server.py"], {"MOCK_DYNAMIC": DYN, "MOCK_IMAP_PORT": str(IMAP), "MOCK_SMTP_PORT": str(SMTP), "MOCK_OUT": T})
    spawn("e1", [BIN, "--db", f"{T}/e1.db"], {"POCT_PORT": str(E1)}); spawn("e2", [BIN, "--db", f"{T}/e2.db"], {"POCT_PORT": str(E2), "POCT_SYNC_SECS": "2"})
    spawn("rl", [BIN, "--relay", "--port", str(RL), "--db", f"{T}/rl.db"]); spawn("al", [BIN, "--db", f"{T}/al.db"], {"POCT_PORT": str(AL), "POCT_CHAT_SECS": "1"}); spawn("bo", [BIN, "--db", f"{T}/bo.db"], {"POCT_PORT": str(BO), "POCT_CHAT_SECS": "1"})
    ok("everything starts", all(wait(lambda p=p: call(p, "/api/accounts" if p != RL else "/relay/health")[0] == 200, 10) for p in (E1, E2, AL, BO, RL))); time.sleep(1)
    s1 = Sse(E1); call(E1, "/api/accounts", ACC)
    ok("first sync downloads 3 messages", bool(wait(lambda: [e for e in s1.of("synced") if e.get("added") == 3]))); ok("no notification for the first sync (history)", s1.of("new_mail") == [])
    eml(101, "Invoice ready 1"); call(E1, "/api/sync", {})
    ok("a genuinely new mail produces one new_mail event", bool(wait(lambda: len(s1.of("new_mail")) == 1))); ev = s1.of("new_mail")[0]
    ok("event carries sender, subject and account", "billing@shop.example" in ev["from"] and ev["subject"] == "Invoice ready 1" and ev["account"] == "n@mock.az")
    for i in range(102, 109): eml(i, f"Invoice ready {i-100}")
    call(E1, "/api/sync", {}); ok("7 more mails reported by the sync", bool(wait(lambda: [e for e in s1.of("synced") if e.get("added") == 7])))
    time.sleep(0.5); ok("notification events are capped at 5 per sync (no flood)", len(s1.of("new_mail")) == 6)
    s2 = Sse(E2); call(E2, "/api/accounts", ACC); wait(lambda: [e for e in s2.of("synced") if e.get("added", 0) > 0], 15); time.sleep(1); base = len(s2.of("new_mail"))
    ok("second device's first sync (11 mails) is silent", base == 0)
    eml(109, "Invoice ready 9")
    ok("POCT_SYNC_SECS=2 -> new mail noticed automatically without a manual refresh", bool(wait(lambda: len(s2.of("new_mail")) == 1, 12)))
    sa = Sse(AL); call(AL, "/api/chat/setup", {"relay_url": f"127.0.0.1:{RL}", "handle": "alice"}); call(BO, "/api/chat/setup", {"relay_url": f"127.0.0.1:{RL}", "handle": "bob"})
    call(BO, "/api/chat/send", {"to": f"alice@127.0.0.1:{RL}", "text": "Salam Alice, bildiriş testi Əə"})
    ok("incoming chat produces an event with sender and text", bool(wait(lambda: sa.of("chat"), 15)) and sa.of("chat")[0]["peer"] == f"bob@127.0.0.1:{RL}" and sa.of("chat")[0]["text"] == "Salam Alice, bildiriş testi Əə")
    call(BO, "/api/chat/send", {"to": f"alice@127.0.0.1:{RL}", "text": "Ə" * 400}); ok("long chat preview is cut on a character boundary (<=200 bytes, valid UTF-8)", bool(wait(lambda: len(sa.of("chat")) == 2, 15)) and len(sa.of("chat")[1]["text"].encode()) <= 200 and set(sa.of("chat")[1]["text"]) == {"Ə"})
    print(f"\nALL {n} NOTIFICATION TESTS PASSED")
finally:
    for pr in procs.values(): pr.terminate()
