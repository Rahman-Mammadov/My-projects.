# Hosting your own free chat relay

**Mail needs no server.** The app talks straight to your mail provider (Gmail, Outlook, Yahoo, your own domain...) over IMAP/SMTP.
A server is only needed for **chat**: a tiny relay that stores *encrypted* messages until the recipient's app picks them up.
The relay never sees message text and holds no private keys (those are created on your device and never leave it).
Everybody can run their own relay, and people on different relays can still talk to each other (address = `username@relay-host`).

## Easiest: Render (free), from a phone
Use the two-file kit **Mail-Relay-Server.zip** (`Dockerfile` + `render.yaml`):
1. Free accounts on github.com and render.com.
2. New GitHub repository, upload the two files.
3. Render: **New, Blueprint**, pick the repository, Apply (first build takes a few minutes).
4. Copy the service address (https://...onrender.com) and the generated `POCT_INVITE` value (service, Environment tab).
5. In the app: Chat tab, paste the address, **Test server**, enter the invite code, pick a username.

Limits of the free plan (verified when this was written, check current terms): the service sleeps after ~15 minutes without traffic, wakes in up to a minute, and its disk is temporary.
What the app does about it:
- keeps the full history on your device;
- re-registers your username automatically if the server forgot it;
- keeps messages it could not deliver in a queue and retries (up to 7 days), showing "Sending..." until they arrive.
What can still go wrong: a message that is *sitting on the server* when it restarts is lost, and a username can be claimed by someone else if the server forgets it and you are offline for long.
Open apps poll every few seconds, which also keeps the free service awake while you chat.

## Always-on (recommended for real use): a free VM
Oracle Cloud "Always Free" or Google Cloud e2-micro give a real VM with a persistent disk (a card may be needed for verification).
1. Create a small Linux VM, open ports 80 and 443, point a (sub)domain (a free DuckDNS name works) at its IP.
2. `sudo apt install build-essential cmake git libcurl4-openssl-dev libsqlite3-dev libsodium-dev`, copy this project over, `cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build && sudo cp build/poct_core /usr/local/bin/`
3. `sudo useradd -r relay`, copy `deploy/poct-relay.service` to `/etc/systemd/system/`, `sudo systemctl enable --now poct-relay`
4. Install Caddy and use `deploy/Caddyfile` (automatic HTTPS). `https://your-domain/relay/health` should return `{"ok":true,...}`.

Relay settings: `PORT`, `POCT_INVITE` (invite-only; recommended), `--db path`. Built-in limits: 64 KB per message, 2000 queued per user, 120 messages/min per IP, 30 days retention.

## Do I need DNS records (SPF / DKIM / DMARC)?
- Gmail/Outlook/Yahoo etc. addresses: no, their servers sign and deliver your mail. Chat: no, it does not use email.
- Only if you send mail from **your own domain** through your own SMTP server or a relay API (Resend, Brevo...): add the SPF, DKIM and DMARC TXT records your provider shows you, otherwise Gmail will likely file your mail as spam. A common DMARC start value on `_dmarc.yourdomain.com`: `v=DMARC1; p=none;`
