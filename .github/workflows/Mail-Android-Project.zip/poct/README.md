# Mail

A private mail client with end-to-end encrypted chat.
Mail goes straight between your provider (any IMAP/SMTP account) and your device, is stored locally and is searchable offline.
Chat messages are sealed on your device with libsodium and travel through a tiny relay server that anyone can host for free.
Runs as an **Android app (Android 12 to 16)**, on **desktop** (browser UI, built from source on Linux/macOS) and as a **relay server**.

## Status
Version 1.0: usable for everyday mail and chat, with the limitations listed below.
It is covered by 215 automated checks (browser UI, mobile layout, security, attachments, notifications, chat, delivery queue) run against a mock IMAP/SMTP server,
on x86-64, on the exact dependency stack used for Android, and on arm64 under emulation. It has **not** been verified against every real provider and has **not** been independently security-audited (see SECURITY.md).

## Features
- **Mail:** any IMAP/SMTP provider (Gmail, Outlook, Yahoo, iCloud, Yandex, Mail.ru, your own domain), multiple accounts, instant offline full-text search, stars, Drafts/Sent/Trash (local), reply, forward, Cc/Bcc.
- **Reading:** HTML mail in a sandboxed frame, tracker images blocked until you allow them, inline images, attachments (download, up to 20 MB when sending, Unicode file names).
- **Writing:** rich-text editor (bold, italic, underline, lists, links), attachments, autosaved drafts.
- **Load older mail:** the first sync fetches the newest 50 messages; "Load older messages" fetches more.
- **Chat:** end-to-end encrypted, works across different relays (`username@relay-host`), safety numbers, automatic retry queue when a relay is asleep or down.
- **Android:** card-based Gmail-like layout with bottom navigation, background sync with notifications for new mail and chat, attachments saved to Downloads.

## Limitations
- Only INBOX is synchronised. Read/starred state, deletions, Sent, Drafts and Trash are local and not mirrored to the server; mail sent from another device does not appear here.
- No OAuth2 sign-in (use app passwords; Gmail, Yahoo and iCloud require them), no push (IMAP IDLE): the phone checks mail every 60 s.
- Data is not encrypted at rest by the app (see SECURITY.md). No forward secrecy and no group chats.
- No Bcc storage in Sent, no attachments inside drafts, attachments are not carried over by Forward.
- Free relay hosts can lose messages that are waiting on the server when they restart.

## Quick start (desktop)
    sudo apt install cmake g++ git libcurl4-openssl-dev libsqlite3-dev libsodium-dev    # macOS: brew install cmake curl sqlite libsodium
    cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build
    ./build/poct_core          # run from this folder; it prints an address with your private key
Open the printed address (`http://127.0.0.1:7878/?t=...`) once and bookmark it, then **Settings / Add account**.
Gmail: create an app password (Google Account, Security, 2-Step Verification, App passwords) and use it instead of your normal password.

## Android
See [ANDROID.md](ANDROID.md): the APK is built by GitHub Actions from your phone's browser, no computer needed.

## Chat server (free)
See [HOSTING.md](HOSTING.md) and the two-file kit in `deploy/relay-kit/` (Dockerfile + render.yaml for Render's free plan, or an always-free VM).

## Tests
    pip install playwright && playwright install chromium
    python3 tools/ui_test.py        # needs: python3 tools/mock_mail_server.py &  and the engine on port 7899 with POCT_TOKEN=testtoken
    POCT_BIN=./build/poct_core python3 tools/security_test.py   # also: rich_test.py, features_test.py, notify_test.py, chat_test.py
Each of these scripts starts everything it needs, except `ui_test.py` (see its header).

## Layout
`core/` C++ engine (IMAP/SMTP/MIME, SQLite+FTS5, chat crypto, relay mode, JNI entry) · `ui/index.html` the whole interface · `android/` Gradle project (WebView + foreground service) ·
`cmake/` from-source dependency build used for Android · `deploy/` relay kit and server files · `tools/` mock mail server and tests.

## License
MIT, see [LICENSE](LICENSE). Third-party components: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
